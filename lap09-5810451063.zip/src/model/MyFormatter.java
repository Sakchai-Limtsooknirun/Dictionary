package model;

public interface MyFormatter {
    String format(Object obj);
}
